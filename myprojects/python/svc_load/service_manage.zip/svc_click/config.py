import os
basedir = os.path.abspath(os.path.dirname(__file__))
import logging

class Config:
    ITALK_PATH = '/home/italk'
    SERVER_ADDR = ('172.16.16.41',)
    DB_IP = '172.16.0.142'
    LOG_LV = logging.ERROR

    @staticmethod
    def init_app(app):
        logging.basicConfig(level=app.config['LOG_LV'])
        logging.info('Log level is %s' % app.config['LOG_LV'])

class DevelopmentConfig(Config):
    LOG_LV = logging.DEBUG

class LoadTestingConfig(Config):
    SERVER_ADDR = ('172.16.16.41', '172.16.16.42', '172.16.16.43',
                   '172.16.16.23', '172.16.16.71', '172.16.16.86')
    DB_IP = '172.16.0.142'
    LOG_LV = logging.INFO

class PreTestingConfig(Config):
    SERVER_ADDR = ('172.16.0.115', '172.16.0.136', '172.16.0.139')
    DB_IP = '172.16.0.142'
    LOG_LV = logging.INFO

config = {
    'development': DevelopmentConfig,
    'loadtest': LoadTestingConfig,
    'pretest': PreTestingConfig,
    'default': DevelopmentConfig,
}
