#!/usr/bin/env python
# -*- coding: utf-8 -*-
from __future__ import absolute_import
from __future__ import print_function
from __future__ import unicode_literals

import re
import os
from suitable import Api
from contextlib import contextmanager
import logging


ITALK_PATH = None
SERVER_ADDR = None
SERVICE_INFO = None
SERVER_LIST = None
SERVICE_LIST = None

@contextmanager
def whit_ansible_api(ip):
    logging.info('ansible conected to %s' % ip)
    api = Api(ip, ignore_errors=True, ignore_unreachable=True)
    yield api
    logging.debug('delete ansible conected to %s' % ip)
    del api

def control_service(ip, service_name, control):
    right_cmd = ['start', 'stop', 'restart', 'status']
    if control not in right_cmd:
        return 1
    cmd = ' '.join(['./service.sh', service_name, control])
    with whit_ansible_api(ip) as api:
        result = api.shell(cmd, chdir=ITALK_PATH)
        response_code = result.rc()
        try:
            pid = re.findall("\d+", result.stdout_lines()[0])[0]
        except IndexError as e:
            pid = None
        return response_code, pid

def update_service(ip, service_name):
    dir_args = os.path.join(ITALK_PATH, service_name)
    svn_path = "svn://172.16.0.204/repos/actest/Server%E7%BB%84%E9%A1%B9%E7%9B%AE/italkIM_update/"
    svn_path = "".join([svn_path, service_name])
    with whit_ansible_api(ip) as api:
        result = api.subversion(repo=svn_path, dest=dir_args)
        if result['contacted'][ip].get('failed'):
            logging.error('{} {} update failed:{}'.format(ip, service_name,
                                                         result['contacted'][ip]['msg']))
        return not result['contacted'][ip].get('failed')

def service_log(ip, service_name, delete=False, *args):
    dir_args = os.path.join(ITALK_PATH, service_name, 'debug')
    with whit_ansible_api(ip) as worker:
        if delete is True:
            dir_args = os.path.join(dir_args, 'log')
            # delete the log directory
            result = worker.file(path=dir_args, state='absent')
            # create a empty log directory
            worker.file(path=dir_args, state='directory')
            return result['contacted'][ip]['changed']
        else:
            cmd = 'du -h --max-depth=0 log | cut -f 1'
            result = worker.shell(cmd, chdir=dir_args)
            return result.stdout()

def service_time(ip, set_time=None):
    with whit_ansible_api(ip) as worker:
        if set_time is None:
            cmd = 'date "+%Y-%m-%d %H:%M:%S"'
        else:
            cmd = " ".join(["date -s", set_time, "'+%Y-%m-%d %H:%M:%S'"])
        result = worker.shell(cmd)
        return result.rc(), result.stdout()

def get_service_info():
    '''init a dict that has ip and service and ip info that get from the path
    of remote server accross ansible api(suitable Api)'''
    global SERVICE_INFO
    if SERVICE_INFO:
        return SERVICE_INFO
    service_info = {}
    for ip in SERVER_ADDR:
        # get dirname list from remote server, path key word is 'debug'.
        with whit_ansible_api(ip) as worker:
            result = worker.find(paths=ITALK_PATH, file_type='directory',
                                 patterns='debug', recurse='yes')
            service_list = result['contacted'][ip]['files']
            service_list = [tmp.get('path') for tmp in service_list]
            service_list = [os.path.basename(os.path.dirname(tmp)) for tmp in service_list]
        service_info[ip] = service_list
    SERVICE_INFO = service_info
    return service_info

def get_server_list():
    '''init a service info dict that prepare translation into json string.
    list = [{'ip': 'x.x.x.x1', 'ser_list': ['lbs','acc', 'class']},
    {'ip': 'x.x.x.x2', 'ser_list': ['lbs','acc', 'class']}]
    '''
    global SERVER_LIST
    if SERVER_LIST:
        return SERVER_LIST
    server_list = []
    for service in get_service_info().items():
        t = {'ip': service[0]}
        t['ser_list'] = service[1]
        server_list.append(t)
    SERVER_LIST = server_list
    return server_list

def get_service_list():
    '''create a list of service point to all server ip address that had
    the service:
    service_list = {'acc':['x.x.x.x', 'x.x.x.x'], }
    '''
    global SERVICE_LIST
    if SERVICE_LIST:
        return SERVICE_LIST
    service_list = {}
    for server in get_server_list():
        for service in server.get('ser_list'):
            if service in service_list:
                service_list[service].append(server.get('ip'))
            else:
                service_list[service] = [server.get('ip'),]
    SERVICE_LIST = service_list
    return service_list

def init_app(app):
    global ITALK_PATH
    global SERVER_ADDR
    ITALK_PATH = app.config['ITALK_PATH']
    SERVER_ADDR = app.config['SERVER_ADDR']
    logging.info('italk exec path is {}'.format(ITALK_PATH))
    logging.info('italk server ip is {}'.format(SERVER_ADDR))
    get_service_info()
    logging.info('italk server info is {}'.format(SERVICE_INFO))

