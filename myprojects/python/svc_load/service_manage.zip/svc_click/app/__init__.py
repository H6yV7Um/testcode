import datetime
from flask import Flask
from flask import render_template, jsonify, request, make_response
from config import config
from lib import serviceAPI
from lib import italkdb

def create_app(config_name):
    app = Flask(__name__)
    app.config.from_object(config[config_name])
    config[config_name].init_app(app)
    serviceAPI.init_app(app)
    italkdb.init_app(app)

    from .main import main as main_blueprint
    app.register_blueprint(main_blueprint)

    from .api_1_0 import api as api_1_0_blueprint
    app.register_blueprint(api_1_0_blueprint, url_prefix='/api/v1.0')

    @app.template_filter('datetimefilter')
    def datetimefilter(value, format='%Y/%m/%d %H:%M:%S'):
        """convert a datetime to a different format."""
        value  = datetime.datetime.fromtimestamp(value)
        return value.strftime(format)

    return app

