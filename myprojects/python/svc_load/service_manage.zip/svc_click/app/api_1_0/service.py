from flask import jsonify, request, make_response

from . import api
from .. import serviceAPI


@api.route('/service/', methods=['POST', 'GET'])
def service_api():
    if request.method == 'POST':
        ip = request.form['ip']
        service, control = request.form['service_control'].split('-')
        try:
            code, pid = serviceAPI.control_service(ip, service, control)
        except (AttributeError, KeyError) as e:
            code = -1
            pid = str(e)
        finally:
            return jsonify({
                'rspcode': code, 'ip': ip,
                'service': service, 'control': control,
                'pid': pid
            })
    else:
        response = make_response(jsonify(serviceAPI.get_server_list()))
        response.headers['Access-Control-Allow-Origin'] = '*'
        return response
