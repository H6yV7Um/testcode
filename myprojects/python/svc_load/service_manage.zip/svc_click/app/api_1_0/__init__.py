from flask import Blueprint

api = Blueprint('api', __name__)

from . import service_time, class_dot_data, service, service_ip_list,\
    service_list, service_log, service_update
