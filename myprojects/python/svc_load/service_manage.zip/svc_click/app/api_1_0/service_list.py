from flask import jsonify

from . import api
from .. import serviceAPI

@api.route('/service_list/', methods=['GET',])
def service_list(ip=None):
    # return all server ip address.
    response = {'service_list': serviceAPI.get_service_list(),
                'service_type': serviceAPI.get_service_list().keys()}
    return jsonify(response)
