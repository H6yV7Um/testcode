from flask import jsonify, request

from . import api
from .. import serviceAPI

@api.route('/service_update/', methods=['POST',])
def service_update_api():
    ip = request.form['ip']
    service = request.form['service']
    response = {'ip': ip, 'service': service}
    result = serviceAPI.update_service(ip ,service)
    if result:
        response['rspcode'] = 0
    else:
        response['rspcode'] = 1
    return jsonify(response)
