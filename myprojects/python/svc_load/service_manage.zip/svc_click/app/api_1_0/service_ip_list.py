from flask import jsonify

from . import api
from .. import serviceAPI
@api.route('/service_ip_list/', methods=['GET',])
def service_ip_list():
    # return all server ip address.
    response = {'ip_list': serviceAPI.SERVER_ADDR}
    return jsonify(response)

