from flask import jsonify, request

from . import api
from .. import serviceAPI

@api.route('/service_log/<ip_service>', methods=['GET', 'POST'])
def service_log_api(ip_service):
    ip, service = ip_service.split('-')
    response = {'ip':ip, 'service':service}
    if request.method == 'GET':
        log_size = serviceAPI.service_log(ip, service)
        if "G" in log_size:
            response['warning'] = True
        response['log_size'] = log_size
    elif request.method == 'POST':
        if request.form['delete']:
            result = serviceAPI.service_log(ip, service, delete=True)
            if result:
                response['rspcode'] = 0
            else:
                response['rspcode'] = 1
    return jsonify(response)
