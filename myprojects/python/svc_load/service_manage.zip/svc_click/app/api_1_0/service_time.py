from flask import jsonify, request

from . import api
from .. import serviceAPI


@api.route('/service_time/<ip>', methods=['GET','POST'])
def service_time_api(ip=None):
    # return only one host's time when 'ip' is given
    if request.method == 'GET' and ip is not None:
        response = {'ip':ip}
        response['rspcode'], response['time'] = serviceAPI.service_time(ip=ip)
    elif request.method == 'POST' and ip is None:
        ip = request.form['ip']
        set_time = request.form['set_time']
        response = {'ip':ip, 'set_time': set_time}
        response['rspcode'], response['time'] =\
            serviceAPI.service_time(ip=ip, set_time=set_time)
    return jsonify(response)

