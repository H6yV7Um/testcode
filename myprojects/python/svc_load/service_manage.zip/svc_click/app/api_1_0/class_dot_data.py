from flask import jsonify

from . import api
from .. import italkdb

@api.route('/class_dot_data/<int:cid>', methods=['GET'])
def class_dot_data(cid):
    result = italkdb.class_dot_data.find_all(id=cid)
    return jsonify(result)
