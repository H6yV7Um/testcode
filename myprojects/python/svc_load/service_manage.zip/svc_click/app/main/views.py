import datetime
import logging
from flask import render_template, request

from . import main
from .. import serviceAPI
from .. import italkdb


@main.route('/servertime', methods=['GET',])
def servertime():
    date, time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S").split()
    return render_template('servertime.html', date=date,
                           time=time, ip_list=serviceAPI.SERVER_ADDR)

@main.route('/', methods=['GET',])
@main.route('/service', methods=['GET',])
def service():
    ser_list = serviceAPI.get_server_list()
    logging.debug('init page ser_list %s' % ser_list)
    ser_type = serviceAPI.get_service_list().keys()
    logging.debug('init page ser_type %s' % ser_type)
    return render_template('service.html', entries=ser_list, types=ser_type)

@main.route('/sdkcheck', methods=['GET',])
def sdkcheck():
    entries = []
    if request.args.get('cid'):
        cid = int(request.args.get('cid'))
        entries = italkdb.class_dot_data.find_all(id=cid)
    return render_template('sdkcheck.html', entries=entries)
