#!/bin/bash

if [ 'venv/bin/activate' ];then
    export FLASK_CONFIG='loadtest'
    source venv/bin/activate
    nohup python manage.py runserver -h 172.16.16.72 -p 5000 --processes 8 &
else
    echo "Can not find virtualenv path named 'venv' in current path!"
fi

